"use client";

import * as React from "react";
import gsap from "gsap";

export function useGsapReveal<T extends HTMLElement>() {
  const ref = React.useRef<T>(null);

  React.useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        element.querySelectorAll("[data-reveal]"),
        { y: 34, opacity: 0, filter: "blur(12px)" },
        {
          y: 0,
          opacity: 1,
          filter: "blur(0px)",
          duration: 1.1,
          stagger: 0.08,
          ease: "power4.out",
          delay: 0.1
        }
      );
    }, element);

    return () => ctx.revert();
  }, []);

  return ref;
}
