import {
  BadgeCheck,
  Clock3,
  Headphones,
  KeyRound,
  ShieldCheck,
  Sparkles
} from "lucide-react";
import type { Feature, NavItem, Product } from "@/types";

export const siteConfig = {
  name: "SHOP BY ISHIGAMI",
  description:
    "Premium digital subscriptions for AI, entertainment and creative tools — delivered fast with trusted support.",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://shopbyishigami.com",
  telegram: process.env.NEXT_PUBLIC_TELEGRAM_URL ?? "https://t.me/yourusername"
};

export const navItems: NavItem[] = [
  { label: "Apps", href: "#apps" },
  { label: "Categories", href: "#categories" },
  { label: "Why us", href: "#why-us" },
  { label: "Reviews", href: "#reviews" },
  { label: "FAQ", href: "#faq" }
];

export const products: Product[] = [
  {
    id: "perplexity-pro",
    name: "Perplexity Pro",
    category: "AI",
    description: "Research faster with advanced models, citations and premium search.",
    price: 8,
    period: "/ month",
    delivery: "5–15 min",
    badge: "Popular",
    features: ["Private activation", "Full Pro access", "Fast delivery"],
    iconText: "P",
    accent: "from-cyan-400/25 via-cyan-300/5 to-transparent",
    featured: true
  },
  {
    id: "claude-pro",
    name: "Claude Pro",
    category: "AI",
    description: "High-context AI assistance for writing, coding, analysis and research.",
    price: 10,
    period: "/ month",
    delivery: "5–20 min",
    features: ["Pro limits", "Priority access", "Secure setup"],
    iconText: "C",
    accent: "from-orange-300/20 via-amber-200/5 to-transparent",
    featured: true
  },
  {
    id: "chatgpt-plus",
    name: "ChatGPT Plus",
    category: "AI",
    description: "Premium ChatGPT access for faster, more capable everyday work.",
    price: 11,
    period: "/ month",
    delivery: "5–15 min",
    badge: "Best Seller",
    features: ["Plus access", "Account-safe flow", "Support included"],
    iconText: "G",
    accent: "from-emerald-300/20 via-teal-200/5 to-transparent",
    featured: true
  },
  {
    id: "gemini-pro",
    name: "Gemini Pro",
    category: "AI",
    description: "Google's premium AI experience for documents, ideas and productivity.",
    price: 7,
    period: "/ month",
    delivery: "10–20 min",
    features: ["Premium AI", "Fast activation", "Simple onboarding"],
    iconText: "✦",
    accent: "from-blue-400/25 via-purple-300/5 to-transparent"
  },
  {
    id: "super-grok",
    name: "Super Grok",
    category: "AI",
    description: "Expanded access to Grok with higher usage and premium capabilities.",
    price: 12,
    period: "/ month",
    delivery: "10–30 min",
    features: ["Premium tier", "Fast processing", "Support included"],
    iconText: "X",
    accent: "from-zinc-100/15 via-zinc-300/5 to-transparent"
  },
  {
    id: "manus-ai",
    name: "Manus AI",
    category: "AI",
    description: "Agentic AI access built for multi-step tasks, research and execution.",
    price: 13,
    period: "/ month",
    delivery: "10–30 min",
    features: ["Agent access", "Premium credits", "Quick setup"],
    iconText: "M",
    accent: "from-violet-400/25 via-fuchsia-300/5 to-transparent"
  },
  {
    id: "kling-ai",
    name: "Kling AI",
    category: "AI",
    description: "Generate cinematic AI video with advanced motion and visual controls.",
    price: 9,
    period: "/ month",
    delivery: "10–20 min",
    features: ["Premium credits", "HD generation", "Fast activation"],
    iconText: "K",
    accent: "from-pink-400/20 via-purple-300/5 to-transparent"
  },
  {
    id: "openart-ai",
    name: "OpenArt AI",
    category: "AI",
    description: "Professional AI image generation with styles, tools and workflows.",
    price: 8,
    period: "/ month",
    delivery: "10–20 min",
    features: ["Premium tools", "High-res output", "Support included"],
    iconText: "O",
    accent: "from-rose-400/20 via-orange-300/5 to-transparent"
  },
  {
    id: "suno",
    name: "Suno",
    category: "AI",
    description: "Create complete songs with AI using premium generation credits.",
    price: 7,
    period: "/ month",
    delivery: "5–15 min",
    features: ["Premium credits", "Commercial-friendly", "Quick setup"],
    iconText: "S",
    accent: "from-fuchsia-400/20 via-violet-300/5 to-transparent"
  },
  {
    id: "netflix",
    name: "Netflix",
    category: "Entertainment",
    description: "Stream premium films and series with a clean, reliable activation flow.",
    price: 5,
    period: "/ month",
    delivery: "Instant–10 min",
    badge: "Popular",
    features: ["HD access", "Fast delivery", "Support included"],
    iconText: "N",
    accent: "from-red-500/25 via-red-400/5 to-transparent",
    featured: true
  },
  {
    id: "disney-plus",
    name: "Disney+",
    category: "Entertainment",
    description: "Movies, originals and franchises from Disney, Pixar, Marvel and more.",
    price: 5,
    period: "/ month",
    delivery: "5–15 min",
    features: ["Premium streaming", "Fast setup", "Support included"],
    iconText: "D+",
    accent: "from-blue-500/25 via-indigo-400/5 to-transparent"
  },
  {
    id: "crunchyroll",
    name: "Crunchyroll",
    category: "Entertainment",
    description: "Premium anime streaming with ad-free access and expanded catalog.",
    price: 4,
    period: "/ month",
    delivery: "5–15 min",
    features: ["Ad-free", "Premium catalog", "Quick delivery"],
    iconText: "C",
    accent: "from-orange-500/25 via-orange-300/5 to-transparent",
    featured: true
  },
  {
    id: "spotify",
    name: "Spotify",
    category: "Entertainment",
    description: "Ad-free listening, downloads and unlimited skips across your devices.",
    price: 4,
    period: "/ month",
    delivery: "5–15 min",
    badge: "Value Pick",
    features: ["No ads", "Offline listening", "High quality audio"],
    iconText: "S",
    accent: "from-green-400/25 via-emerald-300/5 to-transparent",
    featured: true
  },
  {
    id: "apple-music",
    name: "Apple Music",
    category: "Entertainment",
    description: "Lossless music, spatial audio and an elegant ad-free listening experience.",
    price: 4,
    period: "/ month",
    delivery: "5–20 min",
    features: ["Lossless audio", "No ads", "Fast activation"],
    iconText: "♪",
    accent: "from-pink-500/20 via-red-300/5 to-transparent"
  },
  {
    id: "youtube-premium",
    name: "YouTube Premium",
    category: "Entertainment",
    description: "Ad-free YouTube, background playback and premium music access.",
    price: 5,
    period: "/ month",
    delivery: "5–15 min",
    features: ["No ads", "Background play", "YouTube Music"],
    iconText: "▶",
    accent: "from-red-500/20 via-rose-300/5 to-transparent"
  },
  {
    id: "capcut-pro",
    name: "CapCut Pro",
    category: "Productivity",
    description: "Unlock premium editing tools, effects, templates and AI features.",
    price: 6,
    period: "/ month",
    delivery: "5–15 min",
    features: ["Pro effects", "AI tools", "Cloud features"],
    iconText: "C",
    accent: "from-zinc-100/20 via-zinc-200/5 to-transparent"
  },
  {
    id: "telegram-premium",
    name: "Telegram Premium",
    category: "Productivity",
    description: "Premium Telegram features, larger limits, faster downloads and perks.",
    price: 4,
    period: "/ month",
    delivery: "5–15 min",
    features: ["Larger limits", "Premium reactions", "Fast activation"],
    iconText: "T",
    accent: "from-sky-400/25 via-cyan-300/5 to-transparent"
  },
  {
    id: "viber-plus",
    name: "Viber Plus",
    category: "Productivity",
    description: "Expanded Viber features for a cleaner, more expressive messaging experience.",
    price: 3,
    period: "/ month",
    delivery: "5–20 min",
    features: ["Premium features", "Quick setup", "Support included"],
    iconText: "V",
    accent: "from-purple-500/25 via-violet-300/5 to-transparent"
  },
  {
    id: "zoom",
    name: "Zoom Pro",
    category: "Productivity",
    description: "Host longer meetings with premium controls for work and study.",
    price: 7,
    period: "/ month",
    delivery: "10–20 min",
    features: ["Longer meetings", "Cloud tools", "Fast activation"],
    iconText: "Z",
    accent: "from-blue-500/25 via-sky-300/5 to-transparent"
  },
  {
    id: "duolingo",
    name: "Super Duolingo",
    category: "Productivity",
    description: "Learn without ads, unlock unlimited hearts and premium practice tools.",
    price: 4,
    period: "/ month",
    delivery: "5–15 min",
    features: ["No ads", "Unlimited hearts", "Personalized practice"],
    iconText: "D",
    accent: "from-lime-400/25 via-green-300/5 to-transparent"
  }
];

export const features: Feature[] = [
  {
    title: "Human-first delivery",
    description: "Every order is handled with a clear activation flow and direct support when you need it.",
    icon: Sparkles
  },
  {
    title: "Fast turnaround",
    description: "Most products are processed within minutes so you spend less time waiting.",
    icon: Clock3
  },
  {
    title: "Secure process",
    description: "We minimize unnecessary account access and explain what is required before activation.",
    icon: ShieldCheck
  },
  {
    title: "Trusted support",
    description: "Real assistance before and after purchase, not a dead-end automated inbox.",
    icon: Headphones
  },
  {
    title: "Verified access",
    description: "Orders are checked before handoff to reduce activation issues and failed setups.",
    icon: BadgeCheck
  },
  {
    title: "Simple onboarding",
    description: "No confusing checkout maze. Choose a product, message us, and follow a guided setup.",
    icon: KeyRound
  }
];

export const testimonials = [
  {
    name: "Noah T.",
    role: "Designer",
    quote: "The ordering experience feels insanely polished. Delivery was quick and the support reply was clear.",
    avatar: "NT"
  },
  {
    name: "Mika R.",
    role: "Student",
    quote: "I bought two subscriptions and both were activated without the usual back-and-forth. Super smooth.",
    avatar: "MR"
  },
  {
    name: "Aiden K.",
    role: "Creator",
    quote: "Clean pricing, no confusing steps, and the Telegram support actually answers. Exactly what I wanted.",
    avatar: "AK"
  },
  {
    name: "Lina S.",
    role: "Developer",
    quote: "The site looks premium, but more importantly the fulfillment was organized and fast.",
    avatar: "LS"
  },
  {
    name: "Jay P.",
    role: "Editor",
    quote: "CapCut Pro was sorted in minutes. The process felt much safer than random marketplace sellers.",
    avatar: "JP"
  }
];

export const faqs = [
  {
    question: "How does delivery work?",
    answer: "Choose the product you want and continue through Telegram. We confirm the plan, explain any required steps, process the activation, and send confirmation when it is ready."
  },
  {
    question: "How fast will I receive my subscription?",
    answer: "Most products are fulfilled within 5–20 minutes during active hours. A few services can take longer depending on provider-side verification or availability."
  },
  {
    question: "Do you need my password?",
    answer: "Not always. The required activation method depends on the service. When account access is necessary, we explain the exact requirement before you proceed and recommend changing temporary credentials afterward."
  },
  {
    question: "What happens if activation fails?",
    answer: "Contact support with your order details. We verify the issue and provide the appropriate fix, replacement path, or refund handling according to the product and order status."
  },
  {
    question: "Can I buy multiple subscriptions together?",
    answer: "Yes. You can tell us the apps and durations you want in one message and we can organize them as a single order flow."
  }
];
