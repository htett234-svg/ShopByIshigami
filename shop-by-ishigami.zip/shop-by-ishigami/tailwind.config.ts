import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./lib/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ["var(--font-geist)", "Inter", "ui-sans-serif", "system-ui"],
        display: ["var(--font-geist)", "Inter", "ui-sans-serif", "system-ui"]
      },
      colors: {
        ink: "#050505",
        panel: "#0E0E0E",
        muted: "#9A9A9A",
        purple: "#7C5CFF",
        cyan: "#3DEEFF"
      },
      boxShadow: {
        glow: "0 0 80px rgba(124, 92, 255, 0.16)",
        cyan: "0 0 70px rgba(61, 238, 255, 0.12)",
        panel: "0 24px 100px rgba(0,0,0,.45)"
      },
      backgroundImage: {
        "hero-radial": "radial-gradient(circle at 50% 20%, rgba(124,92,255,.17), transparent 35%), radial-gradient(circle at 78% 38%, rgba(61,238,255,.08), transparent 27%)"
      },
      keyframes: {
        shimmer: {
          "0%": { transform: "translateX(-120%)" },
          "100%": { transform: "translateX(120%)" }
        },
        float: {
          "0%, 100%": { transform: "translate3d(0,0,0)" },
          "50%": { transform: "translate3d(0,-12px,0)" }
        },
        marquee: {
          from: { transform: "translateX(0)" },
          to: { transform: "translateX(-50%)" }
        }
      },
      animation: {
        shimmer: "shimmer 2.2s linear infinite",
        float: "float 6s ease-in-out infinite",
        marquee: "marquee 30s linear infinite"
      }
    }
  },
  plugins: []
};

export default config;
