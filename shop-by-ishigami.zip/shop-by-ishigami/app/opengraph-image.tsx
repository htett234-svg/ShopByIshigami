import { ImageResponse } from "next/og";

export const runtime = "edge";
export const alt = "Shop by Ishigami — Premium Apps. Zero Compromise.";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function Image() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: "72px",
          background: "radial-gradient(circle at 70% 20%, #252052 0%, #09090b 36%, #050505 72%)",
          color: "white",
          fontFamily: "sans-serif"
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 18, fontSize: 24, letterSpacing: 6 }}>
          <div style={{ width: 44, height: 44, borderRadius: 12, border: "1px solid rgba(255,255,255,.2)", display: "flex", alignItems: "center", justifyContent: "center" }}>I</div>
          SHOP BY ISHIGAMI
        </div>
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ fontSize: 92, lineHeight: .92, fontWeight: 700, letterSpacing: -6 }}>Premium Apps.</div>
          <div style={{ fontSize: 92, lineHeight: .92, fontWeight: 700, letterSpacing: -6, color: "rgba(255,255,255,.38)" }}>Zero Compromise.</div>
          <div style={{ marginTop: 32, fontSize: 24, color: "rgba(255,255,255,.55)" }}>AI · Entertainment · Productivity</div>
        </div>
      </div>
    ),
    size
  );
}
