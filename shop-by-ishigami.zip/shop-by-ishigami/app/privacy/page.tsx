import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export const metadata = { title: "Privacy Policy" };

export default function PrivacyPage() {
  return (
    <main className="min-h-screen bg-[#050505] px-4 py-24 text-white sm:px-6 lg:px-8">
      <article className="mx-auto max-w-3xl">
        <Link href="/" className="inline-flex items-center gap-2 text-sm text-white/45 transition hover:text-white"><ArrowLeft className="size-4" /> Back home</Link>
        <p className="mt-14 text-[10px] font-medium tracking-[0.2em] text-white/30 uppercase">Legal template</p>
        <h1 className="mt-4 text-4xl font-semibold tracking-[-0.05em] sm:text-6xl">Privacy Policy</h1>
        <div className="mt-10 space-y-8 text-sm leading-7 text-white/55">
          <p><strong className="text-white/85">Before launch:</strong> replace this template with a policy reviewed for your business, location, payment flow, analytics tools and customer-support process.</p>
          <section><h2 className="mb-2 text-lg font-medium text-white">Information we collect</h2><p>We may receive information you voluntarily provide when contacting support or placing an order, such as your name, contact details, order details and information necessary to fulfill the requested service.</p></section>
          <section><h2 className="mb-2 text-lg font-medium text-white">How information is used</h2><p>Information is used to communicate with you, process and support orders, prevent abuse, maintain service quality and comply with applicable legal obligations.</p></section>
          <section><h2 className="mb-2 text-lg font-medium text-white">Third-party services</h2><p>Orders may involve third-party platforms or communication services. Their independent privacy practices may apply when you use those services.</p></section>
          <section><h2 className="mb-2 text-lg font-medium text-white">Retention and security</h2><p>Keep personal information only as long as necessary for legitimate business and legal purposes, and use reasonable safeguards appropriate to the information handled.</p></section>
          <section><h2 className="mb-2 text-lg font-medium text-white">Contact</h2><p>Publish a valid privacy contact method here before launch.</p></section>
        </div>
      </article>
    </main>
  );
}
