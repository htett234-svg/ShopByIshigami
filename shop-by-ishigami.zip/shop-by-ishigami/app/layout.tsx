import type { Metadata, Viewport } from "next";
import { Geist } from "next/font/google";
import "./globals.css";
import { siteConfig } from "@/lib/constants";

const geist = Geist({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-geist"
});

export const metadata: Metadata = {
  metadataBase: new URL(siteConfig.url),
  title: {
    default: "Shop by Ishigami — Premium Digital Subscriptions",
    template: "%s — Shop by Ishigami"
  },
  description: siteConfig.description,
  applicationName: siteConfig.name,
  keywords: [
    "digital subscriptions",
    "premium apps",
    "AI subscriptions",
    "streaming subscriptions",
    "Shop by Ishigami"
  ],
  authors: [{ name: "Shop by Ishigami" }],
  creator: "Shop by Ishigami",
  publisher: "Shop by Ishigami",
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: siteConfig.url,
    siteName: siteConfig.name,
    title: "Shop by Ishigami — Premium Apps. Zero Compromise.",
    description: siteConfig.description
  },
  twitter: {
    card: "summary_large_image",
    title: "Shop by Ishigami — Premium Apps. Zero Compromise.",
    description: siteConfig.description
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
    apple: "/apple-touch-icon.svg"
  },
  manifest: "/manifest.webmanifest"
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  themeColor: "#050505",
  colorScheme: "dark"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body className={`${geist.variable} bg-ink font-sans text-white antialiased`}>
        {children}
      </body>
    </html>
  );
}
