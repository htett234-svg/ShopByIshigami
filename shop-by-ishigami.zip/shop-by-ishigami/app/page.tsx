import { AmbientBackground } from "@/components/effects/ambient-background";
import { BackToTop } from "@/components/effects/back-to-top";
import { CustomCursor } from "@/components/effects/custom-cursor";
import { PageLoader } from "@/components/effects/page-loader";
import { ScrollProgress } from "@/components/effects/scroll-progress";
import { SmoothScroll } from "@/components/effects/smooth-scroll";
import { FloatingDock } from "@/components/layout/floating-dock";
import { Footer } from "@/components/layout/footer";
import { Navbar } from "@/components/layout/navbar";
import { Categories } from "@/components/sections/categories";
import { CTA } from "@/components/sections/cta";
import { FAQ } from "@/components/sections/faq";
import { FeaturedApps } from "@/components/sections/featured-apps";
import { Hero } from "@/components/sections/hero";
import { Stats } from "@/components/sections/stats";
import { Testimonials } from "@/components/sections/testimonials";
import { WhyUs } from "@/components/sections/why-us";
import { siteConfig } from "@/lib/constants";

export default function Home() {
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: siteConfig.name,
    url: siteConfig.url,
    description: siteConfig.description
  };

  return (
    <SmoothScroll>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />
      <PageLoader />
      <CustomCursor />
      <AmbientBackground />
      <ScrollProgress />
      <Navbar />
      <main>
        <Hero />
        <FeaturedApps />
        <Categories />
        <Stats />
        <WhyUs />
        <Testimonials />
        <FAQ />
        <CTA />
      </main>
      <Footer />
      <FloatingDock />
      <BackToTop />
    </SmoothScroll>
  );
}
