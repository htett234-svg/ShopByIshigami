import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Shop by Ishigami",
    short_name: "Ishigami",
    description: "Premium digital subscriptions for AI, entertainment and productivity.",
    start_url: "/",
    display: "standalone",
    background_color: "#050505",
    theme_color: "#050505",
    icons: [
      { src: "/favicon.svg", sizes: "any", type: "image/svg+xml" }
    ]
  };
}
