import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <main className="grid min-h-screen place-items-center bg-[#050505] px-6 text-center text-white">
      <div>
        <p className="text-[10px] font-medium tracking-[0.22em] text-white/30 uppercase">404 — Lost in the grid</p>
        <h1 className="mt-5 text-5xl font-semibold tracking-[-0.055em] sm:text-7xl">Nothing lives here.</h1>
        <p className="mx-auto mt-5 max-w-md text-sm leading-7 text-white/45">The page you requested moved, disappeared, or never existed.</p>
        <Link href="/" className="mx-auto mt-8 inline-flex h-11 items-center gap-2 rounded-full bg-white px-5 text-sm font-medium text-black transition hover:scale-[1.02]">
          <ArrowLeft className="size-4" /> Back home
        </Link>
      </div>
    </main>
  );
}
