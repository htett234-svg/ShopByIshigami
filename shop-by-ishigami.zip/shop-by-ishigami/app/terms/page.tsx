import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export const metadata = { title: "Terms of Service" };

export default function TermsPage() {
  return (
    <main className="min-h-screen bg-[#050505] px-4 py-24 text-white sm:px-6 lg:px-8">
      <article className="mx-auto max-w-3xl">
        <Link href="/" className="inline-flex items-center gap-2 text-sm text-white/45 transition hover:text-white"><ArrowLeft className="size-4" /> Back home</Link>
        <p className="mt-14 text-[10px] font-medium tracking-[0.2em] text-white/30 uppercase">Legal template</p>
        <h1 className="mt-4 text-4xl font-semibold tracking-[-0.05em] sm:text-6xl">Terms of Service</h1>
        <div className="mt-10 space-y-8 text-sm leading-7 text-white/55">
          <p><strong className="text-white/85">Before launch:</strong> replace this template with terms tailored to your actual fulfillment model, refund rules, authorized reseller status, jurisdiction and payment methods.</p>
          <section><h2 className="mb-2 text-lg font-medium text-white">Orders</h2><p>Product availability, delivery estimates and activation requirements should be confirmed at the time of purchase. Do not promise access that you are not authorized or able to provide.</p></section>
          <section><h2 className="mb-2 text-lg font-medium text-white">Customer responsibilities</h2><p>Customers are responsible for providing accurate order information and following lawful, provider-compliant activation instructions.</p></section>
          <section><h2 className="mb-2 text-lg font-medium text-white">Refunds and replacements</h2><p>Publish clear, specific refund and replacement rules for failed fulfillment, customer-caused errors, expired delivery windows and provider-side changes.</p></section>
          <section><h2 className="mb-2 text-lg font-medium text-white">Third-party services</h2><p>Third-party products remain subject to their providers’ applicable terms, regional availability and platform rules. Confirm that your sales model is permitted before offering a product.</p></section>
          <section><h2 className="mb-2 text-lg font-medium text-white">Contact</h2><p>Publish a valid business/support contact method here before launch.</p></section>
        </div>
      </article>
    </main>
  );
}
