# Product icon placeholders

The storefront intentionally uses typographic product marks instead of copied third-party brand assets.
Before launch, add only logos and brand assets you have permission to use, then replace the `iconText`
rendering in `components/sections/product-card.tsx` with `next/image` assets from this folder.
