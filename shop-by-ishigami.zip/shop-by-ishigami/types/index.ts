import type { LucideIcon } from "lucide-react";

export type ProductCategory = "AI" | "Entertainment" | "Productivity";

export type Product = {
  id: string;
  name: string;
  category: ProductCategory;
  description: string;
  price: number;
  period: string;
  delivery: string;
  badge?: string;
  features: string[];
  iconText: string;
  accent: string;
  featured?: boolean;
};

export type NavItem = {
  label: string;
  href: string;
};

export type Feature = {
  title: string;
  description: string;
  icon: LucideIcon;
};
