import { ArrowUpRight, Send } from "lucide-react";
import { navItems, siteConfig } from "@/lib/constants";

export function Footer() {
  return (
    <footer className="px-4 pb-7 pt-20 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl overflow-hidden rounded-[32px] border border-white/[0.08] bg-white/[0.025] shadow-panel backdrop-blur-xl">
        <div className="grid gap-10 px-6 py-10 md:grid-cols-[1.35fr_.65fr_.65fr] md:px-10 md:py-14">
          <div>
            <div className="mb-5 flex items-center gap-3">
              <span className="grid size-9 place-items-center rounded-xl border border-white/10 bg-gradient-to-br from-purple/20 to-cyan/10 text-xs font-bold">I</span>
              <span className="text-[12px] font-medium tracking-[0.25em] text-white/85">SHOP BY ISHIGAMI</span>
            </div>
            <p className="max-w-md text-sm leading-7 text-white/45">
              A curated storefront for premium digital subscriptions, designed around fast delivery, clear communication and a better buying experience.
            </p>
          </div>
          <div>
            <p className="mb-4 text-[10px] font-semibold tracking-[0.2em] text-white/30 uppercase">Navigate</p>
            <div className="grid gap-3">
              {navItems.slice(0, 4).map((item) => (
                <a key={item.href} href={item.href} className="text-sm text-white/50 transition hover:text-white">
                  {item.label}
                </a>
              ))}
            </div>
          </div>
          <div>
            <p className="mb-4 text-[10px] font-semibold tracking-[0.2em] text-white/30 uppercase">Connect</p>
            <a
              href={siteConfig.telegram}
              target="_blank"
              rel="noreferrer"
              className="group inline-flex items-center gap-2 text-sm text-white/60 transition hover:text-white"
            >
              <Send className="size-4" /> Telegram <ArrowUpRight className="size-3.5 transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </a>
          </div>
        </div>
        <div className="flex flex-col gap-3 border-t border-white/[0.07] px-6 py-5 text-[11px] text-white/30 sm:flex-row sm:items-center sm:justify-between md:px-10">
          <p>© {new Date().getFullYear()} Shop by Ishigami. All rights reserved.</p>
          <div className="flex items-center gap-4"><a href="/privacy" className="transition hover:text-white/60">Privacy</a><a href="/terms" className="transition hover:text-white/60">Terms</a><span>Crafted for speed, trust &amp; delight.</span></div>
        </div>
      </div>
    </footer>
  );
}
