"use client";

import * as React from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, Send, X } from "lucide-react";
import { navItems, siteConfig } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Magnetic } from "@/components/effects/magnetic";

export function Navbar() {
  const [open, setOpen] = React.useState(false);
  const [scrolled, setScrolled] = React.useState(false);

  React.useEffect(() => {
    const update = () => setScrolled(window.scrollY > 20);
    update();
    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, []);

  React.useEffect(() => {
    if (!open) return;
    const close = () => setOpen(false);
    window.addEventListener("resize", close);
    return () => window.removeEventListener("resize", close);
  }, [open]);

  return (
    <header className="fixed inset-x-0 top-0 z-[90] px-3 pt-3 sm:px-5 sm:pt-4">
      <motion.nav
        animate={{
          backgroundColor: scrolled ? "rgba(8,8,8,.72)" : "rgba(8,8,8,.38)",
          borderColor: scrolled ? "rgba(255,255,255,.11)" : "rgba(255,255,255,.07)"
        }}
        className="mx-auto flex h-14 max-w-7xl items-center justify-between rounded-2xl border px-4 shadow-[0_12px_60px_rgba(0,0,0,.25)] backdrop-blur-2xl sm:h-16 sm:px-5"
      >
        <a href="#top" className="group inline-flex items-center gap-3" data-cursor="View">
          <span className="relative grid size-8 place-items-center overflow-hidden rounded-lg border border-white/10 bg-white/[0.05]">
            <span className="absolute inset-0 bg-gradient-to-br from-purple/30 via-transparent to-cyan/20 opacity-80" />
            <span className="relative text-[12px] font-bold tracking-tight text-white">I</span>
          </span>
          <span className="hidden text-[11px] font-medium tracking-[0.24em] text-white/85 sm:block">SHOP BY ISHIGAMI</span>
        </a>

        <div className="hidden items-center gap-1 lg:flex">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="group relative rounded-full px-4 py-2 text-[13px] text-white/55 transition-colors hover:text-white"
            >
              {item.label}
              <span className="absolute inset-x-4 bottom-1 h-px origin-left scale-x-0 bg-gradient-to-r from-purple to-cyan transition-transform duration-300 group-hover:scale-x-100" />
            </a>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <Magnetic className="hidden sm:block">
            <Button asChild variant="outline" size="sm">
              <a href={siteConfig.telegram} target="_blank" rel="noreferrer" data-cursor="Join">
                <Send className="size-3.5" />
                Telegram
              </a>
            </Button>
          </Magnetic>
          <button
            type="button"
            className="grid size-9 place-items-center rounded-full border border-white/10 bg-white/[0.035] text-white lg:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((value) => !value)}
          >
            {open ? <X className="size-4" /> : <Menu className="size-4" />}
          </button>
        </div>
      </motion.nav>

      <AnimatePresence>
        {open ? (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.98 }}
            transition={{ duration: 0.25 }}
            className="mx-auto mt-2 max-w-7xl overflow-hidden rounded-2xl border border-white/10 bg-black/85 p-3 shadow-panel backdrop-blur-2xl lg:hidden"
          >
            {navItems.map((item, index) => (
              <motion.a
                key={item.href}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.035 }}
                href={item.href}
                onClick={() => setOpen(false)}
                className="flex items-center justify-between rounded-xl px-4 py-3 text-sm text-white/70 hover:bg-white/[0.05] hover:text-white"
              >
                <span>{item.label}</span>
                <span className="text-white/20">0{index + 1}</span>
              </motion.a>
            ))}
            <Button asChild variant="gradient" className="mt-2 w-full">
              <a href={siteConfig.telegram} target="_blank" rel="noreferrer">
                <Send className="size-4" /> Join Telegram
              </a>
            </Button>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </header>
  );
}
