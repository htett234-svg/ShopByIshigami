"use client";

import { motion } from "framer-motion";
import { Bot, CircleHelp, Home, Send, ShoppingBag } from "lucide-react";
import { siteConfig } from "@/lib/constants";

const items = [
  { label: "Home", href: "#top", icon: Home },
  { label: "Apps", href: "#apps", icon: ShoppingBag },
  { label: "AI", href: "#categories", icon: Bot },
  { label: "FAQ", href: "#faq", icon: CircleHelp }
];

export function FloatingDock() {
  return (
    <motion.div
      initial={{ y: 30, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 2.2, duration: 0.7 }}
      className="fixed bottom-5 left-1/2 z-50 hidden -translate-x-1/2 items-center gap-1 rounded-2xl border border-white/10 bg-black/55 p-1.5 shadow-[0_15px_70px_rgba(0,0,0,.4)] backdrop-blur-2xl md:flex"
    >
      {items.map((item) => (
        <a
          key={item.href}
          href={item.href}
          aria-label={item.label}
          data-cursor="View"
          className="group relative grid size-10 place-items-center rounded-xl text-white/45 transition hover:bg-white/[0.06] hover:text-white"
        >
          <item.icon className="size-4" />
          <span className="pointer-events-none absolute -top-9 rounded-md border border-white/10 bg-black/80 px-2 py-1 text-[10px] text-white/70 opacity-0 backdrop-blur-xl transition group-hover:opacity-100">
            {item.label}
          </span>
        </a>
      ))}
      <div className="mx-1 h-5 w-px bg-white/10" />
      <a
        href={siteConfig.telegram}
        target="_blank"
        rel="noreferrer"
        aria-label="Telegram"
        data-cursor="Join"
        className="grid size-10 place-items-center rounded-xl bg-white text-black transition hover:scale-[1.04]"
      >
        <Send className="size-4" />
      </a>
    </motion.div>
  );
}
