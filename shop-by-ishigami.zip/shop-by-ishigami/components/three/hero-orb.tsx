"use client";

import * as React from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";

function Orb() {
  const group = React.useRef<THREE.Group>(null);
  const outer = React.useRef<THREE.Mesh>(null);

  useFrame((state, delta) => {
    if (!group.current || !outer.current) return;
    group.current.rotation.y += delta * 0.11;
    group.current.position.y = Math.sin(state.clock.elapsedTime * 0.8) * 0.08;
    group.current.rotation.x = THREE.MathUtils.lerp(group.current.rotation.x, state.pointer.y * 0.16, 0.04);
    group.current.rotation.y = THREE.MathUtils.lerp(group.current.rotation.y, state.pointer.x * 0.24 + group.current.rotation.y, 0.025);
    const scale = 1 + Math.sin(state.clock.elapsedTime * 1.35) * 0.018;
    outer.current.scale.setScalar(scale);
  });

  return (
      <group ref={group}>
        <mesh ref={outer}>
          <icosahedronGeometry args={[1.55, 5]} />
          <meshPhysicalMaterial
            color="#161320"
            roughness={0.14}
            metalness={0.2}
            transmission={0.18}
            thickness={1.8}
            clearcoat={1}
            clearcoatRoughness={0.2}
            emissive="#261e4f"
            emissiveIntensity={0.32}
          />
        </mesh>
        <mesh scale={1.03}>
          <icosahedronGeometry args={[1.55, 2]} />
          <meshBasicMaterial color="#7C5CFF" wireframe transparent opacity={0.15} />
        </mesh>
        <mesh rotation={[0.4, -0.25, 0.8]}>
          <torusGeometry args={[2.08, 0.012, 16, 180]} />
          <meshBasicMaterial color="#3DEEFF" transparent opacity={0.42} />
        </mesh>
        <mesh rotation={[-0.8, 0.6, -0.25]}>
          <torusGeometry args={[1.86, 0.008, 12, 160]} />
          <meshBasicMaterial color="#FFFFFF" transparent opacity={0.18} />
        </mesh>
      </group>
  );
}

export default function HeroOrb() {
  return (
    <div className="h-full w-full" aria-hidden>
      <Canvas dpr={[1, 1.5]} camera={{ position: [0, 0, 5.5], fov: 42 }} gl={{ antialias: true, alpha: true }}>
        <ambientLight intensity={0.75} />
        <pointLight position={[3, 2, 4]} intensity={20} color="#7C5CFF" distance={8} />
        <pointLight position={[-3, -1, 3]} intensity={14} color="#3DEEFF" distance={7} />
        <Orb />
      </Canvas>
    </div>
  );
}
