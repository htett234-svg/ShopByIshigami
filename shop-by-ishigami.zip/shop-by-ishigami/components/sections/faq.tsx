import { faqs } from "@/lib/constants";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { SectionHeading } from "@/components/ui/section-heading";

export function FAQ() {
  return (
    <section id="faq" className="px-4 py-24 sm:px-6 sm:py-32 lg:px-8">
      <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[.72fr_1.28fr] lg:gap-20">
        <SectionHeading
          eyebrow="FAQ"
          title={<>Answers without <span className="text-white/35">the support ticket.</span></>}
          description="The common questions, answered upfront. Product-specific requirements can still vary by provider."
        />
        <div className="rounded-[28px] border border-white/[0.08] bg-white/[0.022] px-6 sm:px-8">
          <Accordion type="single" collapsible>
            {faqs.map((faq, index) => (
              <AccordionItem key={faq.question} value={`item-${index}`}>
                <AccordionTrigger>{faq.question}</AccordionTrigger>
                <AccordionContent>{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
