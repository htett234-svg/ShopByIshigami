"use client";

import { motion } from "framer-motion";
import { features } from "@/lib/constants";
import { SectionHeading } from "@/components/ui/section-heading";

export function WhyUs() {
  return (
    <section id="why-us" className="px-4 py-24 sm:px-6 sm:py-32 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-12 lg:grid-cols-[.8fr_1.2fr] lg:gap-20">
          <div className="lg:sticky lg:top-28 lg:self-start">
            <SectionHeading
              eyebrow="Why Ishigami"
              title={<>Digital buying should feel <span className="text-white/35">this effortless.</span></>}
              description="The interface is premium, but the real product is clarity: simple choices, responsive support and a delivery flow designed to remove uncertainty."
            />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {features.map((feature, index) => (
              <motion.article
                key={feature.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ delay: index * 0.05, duration: 0.65 }}
                whileHover={{ y: -4 }}
                className="group relative min-h-56 overflow-hidden rounded-[26px] border border-white/[0.08] bg-white/[0.025] p-6"
              >
                <div className="absolute -right-12 -top-12 size-40 rounded-full bg-purple/[0.06] blur-2xl transition duration-500 group-hover:bg-cyan/[0.08]" />
                <span className="relative mb-12 grid size-10 place-items-center rounded-xl border border-white/10 bg-white/[0.045] text-white/65 transition group-hover:border-white/20 group-hover:text-white">
                  <feature.icon className="size-[18px]" />
                </span>
                <h3 className="relative text-lg font-medium tracking-[-0.02em] text-white">{feature.title}</h3>
                <p className="relative mt-3 text-sm leading-6 text-white/40">{feature.description}</p>
              </motion.article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
