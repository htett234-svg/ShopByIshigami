"use client";

import * as React from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Search, SlidersHorizontal, X } from "lucide-react";
import { products } from "@/lib/constants";
import type { ProductCategory } from "@/types";
import { ProductCard } from "@/components/sections/product-card";
import { SectionHeading } from "@/components/ui/section-heading";
import { cn } from "@/lib/utils";

const categories: Array<"All" | ProductCategory> = ["All", "AI", "Entertainment", "Productivity"];

export function FeaturedApps() {
  const [query, setQuery] = React.useState("");
  const [category, setCategory] = React.useState<(typeof categories)[number]>("All");
  const [showAll, setShowAll] = React.useState(false);

  const filtered = React.useMemo(() => {
    const normalized = query.toLowerCase().trim();
    return products.filter((product) => {
      const inCategory = category === "All" || product.category === category;
      const matches = !normalized || `${product.name} ${product.category} ${product.description}`.toLowerCase().includes(normalized);
      return inCategory && matches;
    });
  }, [category, query]);

  const visibleProducts = showAll || query || category !== "All" ? filtered : filtered.filter((p) => p.featured).slice(0, 6);

  return (
    <section id="apps" className="relative px-4 py-24 sm:px-6 sm:py-32 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="flex flex-col gap-10 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading
            eyebrow="The Collection"
            title={<>Apps worth paying for. <span className="text-white/35">Without the friction.</span></>}
            description="Search the collection, filter by category, and jump straight to the subscription you want. Pricing below is placeholder content—replace it with your live catalog before launch."
          />
          <div className="w-full max-w-lg">
            <div className="group relative">
              <Search className="absolute left-4 top-1/2 size-4 -translate-y-1/2 text-white/30 transition group-focus-within:text-cyan" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search apps…"
                aria-label="Search apps"
                className="h-12 w-full rounded-2xl border border-white/10 bg-white/[0.035] pl-11 pr-11 text-sm text-white outline-none backdrop-blur-xl transition placeholder:text-white/25 focus:border-white/20 focus:bg-white/[0.05] focus:ring-4 focus:ring-purple/5"
              />
              {query ? (
                <button onClick={() => setQuery("")} aria-label="Clear search" className="absolute right-3 top-1/2 grid size-7 -translate-y-1/2 place-items-center rounded-full text-white/30 hover:bg-white/[0.05] hover:text-white">
                  <X className="size-3.5" />
                </button>
              ) : null}
            </div>
          </div>
        </div>

        <div className="mt-8 flex flex-wrap items-center gap-2 border-y border-white/[0.06] py-4">
          <span className="mr-2 inline-flex items-center gap-2 text-[11px] text-white/30"><SlidersHorizontal className="size-3.5" /> Filter</span>
          {categories.map((item) => (
            <button
              key={item}
              onClick={() => setCategory(item)}
              className={cn(
                "rounded-full border px-3.5 py-2 text-xs transition",
                category === item
                  ? "border-white/20 bg-white text-black"
                  : "border-white/[0.07] bg-white/[0.025] text-white/45 hover:border-white/15 hover:text-white"
              )}
            >
              {item}
            </button>
          ))}
          <span className="ml-auto text-[11px] text-white/25">{filtered.length} results</span>
        </div>

        <AnimatePresence mode="popLayout">
          {visibleProducts.length ? (
            <motion.div layout className="mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {visibleProducts.map((product, index) => (
                <motion.div key={product.id} layout>
                  <ProductCard product={product} index={index} />
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-8 grid min-h-72 place-items-center rounded-[28px] border border-dashed border-white/10 bg-white/[0.02] text-center">
              <div>
                <p className="text-sm font-medium text-white/65">No apps found</p>
                <p className="mt-2 text-xs text-white/30">Try another search or category.</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {!query && category === "All" ? (
          <div className="mt-8 flex justify-center">
            <button
              onClick={() => setShowAll((value) => !value)}
              className="rounded-full border border-white/10 bg-white/[0.03] px-5 py-2.5 text-xs font-medium text-white/55 transition hover:border-white/20 hover:bg-white/[0.05] hover:text-white"
            >
              {showAll ? "Show featured only" : `Explore all ${products.length} apps`}
            </button>
          </div>
        ) : null}
      </div>
    </section>
  );
}
