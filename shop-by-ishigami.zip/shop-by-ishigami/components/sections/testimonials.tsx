"use client";

import * as React from "react";
import { Quote, Star } from "lucide-react";
import { testimonials } from "@/lib/constants";
import { SectionHeading } from "@/components/ui/section-heading";

export function Testimonials() {
  const loop = [...testimonials, ...testimonials];
  const railRef = React.useRef<HTMLDivElement>(null);
  const drag = React.useRef({ active: false, startX: 0, scrollLeft: 0 });
  const [dragging, setDragging] = React.useState(false);

  const onPointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    const rail = railRef.current;
    if (!rail) return;
    drag.current = { active: true, startX: event.clientX, scrollLeft: rail.scrollLeft };
    rail.setPointerCapture(event.pointerId);
    setDragging(true);
  };

  const onPointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    const rail = railRef.current;
    if (!rail || !drag.current.active) return;
    rail.scrollLeft = drag.current.scrollLeft - (event.clientX - drag.current.startX);
  };

  const stopDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    drag.current.active = false;
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
    setDragging(false);
  };
  return (
    <section id="reviews" className="overflow-hidden py-24 sm:py-32">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionHeading
            eyebrow="Customer notes"
            title={<>Small details. <span className="text-white/35">Big difference.</span></>}
            description="Sample testimonial content is included for the design. Replace these with verified customer reviews before publishing."
          />
        </div>
      </div>

      <div
        ref={railRef}
        data-cursor="Drag"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={stopDrag}
        onPointerCancel={stopDrag}
        className="relative mt-12 overflow-x-hidden select-none touch-pan-y [mask-image:linear-gradient(to_right,transparent,black_8%,black_92%,transparent)]"
      >
        <div
          className="flex w-max animate-marquee gap-4 px-4 hover:[animation-play-state:paused]"
          style={{ animationPlayState: dragging ? "paused" : undefined }}
        >
          {loop.map((item, index) => (
            <article key={`${item.name}-${index}`} className="w-[320px] shrink-0 rounded-[26px] border border-white/[0.08] bg-white/[0.028] p-6 backdrop-blur-xl sm:w-[380px]">
              <div className="flex items-center justify-between">
                <Quote className="size-5 text-purple/60" />
                <div className="flex gap-0.5 text-cyan/70">
                  {Array.from({ length: 5 }).map((_, i) => <Star key={i} className="size-3 fill-current" />)}
                </div>
              </div>
              <p className="mt-7 min-h-24 text-sm leading-7 text-white/65">“{item.quote}”</p>
              <div className="mt-7 flex items-center gap-3 border-t border-white/[0.07] pt-5">
                <div className="grid size-10 place-items-center rounded-full border border-white/10 bg-gradient-to-br from-purple/20 to-cyan/10 text-xs font-semibold text-white/70">{item.avatar}</div>
                <div>
                  <p className="text-sm font-medium text-white/80">{item.name}</p>
                  <p className="mt-0.5 text-[11px] text-white/30">{item.role}</p>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
