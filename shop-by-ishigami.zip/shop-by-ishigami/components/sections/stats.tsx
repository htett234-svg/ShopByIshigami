"use client";

import * as React from "react";
import { motion, useInView } from "framer-motion";

function Counter({ to, suffix = "", decimals = 0 }: { to: number; suffix?: string; decimals?: number }) {
  const ref = React.useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.7 });
  const [value, setValue] = React.useState(0);

  React.useEffect(() => {
    if (!inView) return;
    const duration = 1200;
    const start = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 4);
      setValue(to * eased);
      if (progress < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, to]);

  return <span ref={ref}>{value.toFixed(decimals)}{suffix}</span>;
}

const stats = [
  { value: 10000, suffix: "+", label: "Happy customers", compact: true },
  { value: 99.9, suffix: "%", label: "Delivery success", decimals: 1 },
  { value: 24, suffix: "/7", label: "Support access" }
];

export function Stats() {
  return (
    <section className="px-4 py-10 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.25 }}
        className="mx-auto grid max-w-7xl overflow-hidden rounded-[30px] border border-white/[0.08] bg-white/[0.025] md:grid-cols-3"
      >
        {stats.map((stat, index) => (
          <div key={stat.label} className="relative p-7 sm:p-9 md:p-10">
            {index > 0 ? <div className="absolute left-0 top-1/2 hidden h-16 w-px -translate-y-1/2 bg-gradient-to-b from-transparent via-white/10 to-transparent md:block" /> : null}
            <div className="text-4xl font-semibold tracking-[-0.055em] text-white sm:text-5xl">
              {stat.compact ? (
                <><Counter to={10} />K+</>
              ) : (
                <Counter to={stat.value} suffix={stat.suffix} decimals={stat.decimals} />
              )}
            </div>
            <p className="mt-3 text-xs tracking-[0.08em] text-white/35 uppercase">{stat.label}</p>
          </div>
        ))}
      </motion.div>
    </section>
  );
}
