"use client";

import { motion } from "framer-motion";
import { Bot, Film, Layers3, Music2, WandSparkles } from "lucide-react";
import { SectionHeading } from "@/components/ui/section-heading";

const cards = [
  {
    title: "AI Intelligence",
    description: "Research, writing, coding, video, image and music generation in one curated collection.",
    href: "#apps",
    icon: Bot,
    meta: "9 apps",
    className: "md:col-span-2 md:row-span-2 min-h-[360px]"
  },
  {
    title: "Streaming",
    description: "Movies, series and anime without the clutter.",
    href: "#apps",
    icon: Film,
    meta: "3 apps",
    className: "min-h-[174px]"
  },
  {
    title: "Music",
    description: "Premium listening and discovery.",
    href: "#apps",
    icon: Music2,
    meta: "3 apps",
    className: "min-h-[174px]"
  },
  {
    title: "Productivity",
    description: "Creative, communication and learning tools for everyday momentum.",
    href: "#apps",
    icon: Layers3,
    meta: "5 apps",
    className: "md:col-span-2 min-h-[220px]"
  }
];

export function Categories() {
  return (
    <section id="categories" className="px-4 py-24 sm:px-6 sm:py-32 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <SectionHeading
          eyebrow="Categories"
          title={<>A compact store. <span className="text-white/35">A bigger digital life.</span></>}
          description="Built around the subscriptions people actually use, with fewer distractions and faster paths to purchase."
        />

        <div className="mt-12 grid gap-4 md:grid-cols-4 md:grid-rows-2">
          {cards.map((card, index) => (
            <motion.a
              key={card.title}
              href={card.href}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.15 }}
              transition={{ delay: index * 0.06, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
              whileHover={{ y: -5 }}
              data-cursor="View"
              className={`group relative overflow-hidden rounded-[28px] border border-white/[0.08] bg-[#0c0c0e] p-6 shadow-panel ${card.className}`}
            >
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_15%,rgba(124,92,255,.16),transparent_25%),radial-gradient(circle_at_20%_85%,rgba(61,238,255,.07),transparent_30%)] opacity-70 transition duration-500 group-hover:scale-110 group-hover:opacity-100" />
              <div className="absolute inset-0 bg-[linear-gradient(120deg,transparent_30%,rgba(255,255,255,.035)_48%,transparent_66%)] translate-x-[-120%] transition-transform duration-1000 group-hover:translate-x-[120%]" />
              <div className="relative flex h-full flex-col justify-between">
                <div className="flex items-start justify-between gap-4">
                  <span className="grid size-11 place-items-center rounded-2xl border border-white/10 bg-white/[0.045] text-white/70">
                    <card.icon className="size-5" />
                  </span>
                  <span className="text-[10px] tracking-[0.16em] text-white/25 uppercase">{card.meta}</span>
                </div>
                <div className={index === 0 ? "max-w-md" : ""}>
                  {index === 0 ? <WandSparkles className="mb-5 size-5 text-cyan/70" /> : null}
                  <h3 className={index === 0 ? "text-3xl font-semibold tracking-[-0.04em] text-white sm:text-4xl" : "text-xl font-semibold tracking-[-0.03em] text-white"}>
                    {card.title}
                  </h3>
                  <p className="mt-3 max-w-lg text-sm leading-6 text-white/40">{card.description}</p>
                </div>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
