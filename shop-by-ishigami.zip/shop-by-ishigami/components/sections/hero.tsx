"use client";

import dynamic from "next/dynamic";
import { ArrowRight, Send, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Magnetic } from "@/components/effects/magnetic";
import { siteConfig } from "@/lib/constants";
import { useGsapReveal } from "@/hooks/use-gsap-reveal";
import { ScrambleText } from "@/components/effects/scramble-text";
import { useMediaQuery } from "@/hooks/use-media-query";

const HeroOrb = dynamic(() => import("@/components/three/hero-orb"), {
  ssr: false,
  loading: () => <div className="h-full w-full animate-pulse rounded-full bg-purple/5 blur-3xl" />
});

export function Hero() {
  const ref = useGsapReveal<HTMLElement>();
  const desktop = useMediaQuery("(min-width: 1024px)");

  return (
    <section ref={ref} id="top" className="relative min-h-[100svh] overflow-hidden px-4 pb-16 pt-28 sm:px-6 sm:pt-32 lg:px-8">
      <div className="absolute inset-0 -z-[1] bg-hero-radial" />
      <div className="mx-auto grid min-h-[calc(100svh-9rem)] max-w-7xl items-center gap-8 lg:grid-cols-[1.08fr_.92fr]">
        <div className="relative z-10 max-w-4xl pt-6 lg:pt-0">
          <div data-reveal className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.035] px-3 py-1.5 text-[11px] text-white/55 backdrop-blur-xl">
            <Sparkles className="size-3.5 text-cyan" />
            <ScrambleText text="Curated premium subscriptions" />
          </div>

          <h1 className="text-balance text-[clamp(3.2rem,8vw,7.7rem)] font-semibold leading-[0.86] tracking-[-0.072em] text-white">
            <span data-reveal className="block">Premium Apps.</span>
            <span data-reveal className="relative mt-1 block pb-3 text-white/42">
              Zero Compromise.
              <span className="absolute -bottom-1 left-1 h-px w-[42%] bg-gradient-to-r from-purple via-cyan/60 to-transparent" />
            </span>
          </h1>

          <p data-reveal className="mt-7 max-w-xl text-pretty text-sm leading-7 text-white/48 sm:text-base sm:leading-8">
            Premium access to the tools you use every day—AI, streaming, music and productivity—wrapped in a faster, clearer buying experience.
          </p>

          <div data-reveal className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Magnetic>
              <Button asChild size="lg" variant="default" className="w-full sm:w-auto">
                <a href="#apps" data-cursor="View">
                  Browse Apps <ArrowRight className="size-4" />
                </a>
              </Button>
            </Magnetic>
            <Magnetic>
              <Button asChild size="lg" variant="outline" className="w-full sm:w-auto">
                <a href={siteConfig.telegram} target="_blank" rel="noreferrer" data-cursor="Join">
                  <Send className="size-4" /> Join Telegram
                </a>
              </Button>
            </Magnetic>
          </div>

          <div data-reveal className="mt-10 flex flex-wrap items-center gap-x-6 gap-y-3 text-[11px] text-white/35">
            <span className="inline-flex items-center gap-2"><span className="size-1.5 rounded-full bg-emerald-300 shadow-[0_0_14px_rgba(110,231,183,.8)]" /> Online support</span>
            <span>Fast digital delivery</span>
            <span>Transparent pricing</span>
          </div>
        </div>

        <div className="relative hidden h-[620px] min-w-0 lg:block" data-reveal>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(124,92,255,.18),transparent_45%)] blur-2xl" />
          <div className="absolute inset-0">
            {desktop ? <HeroOrb /> : null}
          </div>
          <div className="absolute left-0 top-[22%] rounded-2xl border border-white/10 bg-black/30 px-4 py-3 backdrop-blur-xl animate-float">
            <p className="text-[10px] tracking-[0.16em] text-white/30 uppercase">Delivery</p>
            <p className="mt-1 text-sm font-medium text-white/85">Minutes, not days.</p>
          </div>
          <div className="absolute bottom-[20%] right-0 rounded-2xl border border-white/10 bg-black/30 px-4 py-3 backdrop-blur-xl [animation-delay:1.1s] animate-float">
            <p className="text-[10px] tracking-[0.16em] text-white/30 uppercase">Support</p>
            <p className="mt-1 text-sm font-medium text-white/85">Human when it matters.</p>
          </div>
        </div>
      </div>

      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-[#050505] to-transparent" />
    </section>
  );
}
