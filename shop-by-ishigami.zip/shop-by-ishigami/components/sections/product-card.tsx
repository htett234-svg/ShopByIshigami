"use client";

import * as React from "react";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { ArrowUpRight, Check, Clock3 } from "lucide-react";
import type { Product } from "@/types";
import { formatPrice } from "@/lib/utils";
import { siteConfig } from "@/lib/constants";

export function ProductCard({ product, index }: { product: Product; index: number }) {
  const cardRef = React.useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rotateX = useSpring(useTransform(y, [-0.5, 0.5], [8, -8]), { stiffness: 180, damping: 22 });
  const rotateY = useSpring(useTransform(x, [-0.5, 0.5], [-8, 8]), { stiffness: 180, damping: 22 });
  const glowX = useTransform(x, [-0.5, 0.5], [0, 100]);
  const glowY = useTransform(y, [-0.5, 0.5], [0, 100]);

  const onMouseMove = (event: React.MouseEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    x.set((event.clientX - rect.left) / rect.width - 0.5);
    y.set((event.clientY - rect.top) / rect.height - 0.5);
  };

  const reset = () => {
    x.set(0);
    y.set(0);
  };

  const telegramUrl = siteConfig.telegram;

  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, y: 30, filter: "blur(10px)" }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once: true, amount: 0.12 }}
      transition={{ duration: 0.7, delay: Math.min(index * 0.045, 0.35), ease: [0.22, 1, 0.36, 1] }}
      style={{ rotateX, rotateY, transformPerspective: 1000, transformStyle: "preserve-3d" }}
      onMouseMove={onMouseMove}
      onMouseLeave={reset}
      className="group relative min-h-[410px] overflow-hidden rounded-[28px] border border-white/[0.08] bg-[#0b0b0d]/90 p-[1px] shadow-[0_22px_80px_rgba(0,0,0,.32)] will-change-transform"
      data-cursor="View"
    >
      <div className={`absolute inset-0 bg-gradient-to-br ${product.accent} opacity-90`} />
      <motion.div
        aria-hidden
        className="absolute -inset-20 rounded-full bg-white/[0.12] blur-[70px]"
        style={{ left: glowX, top: glowY, width: 100, height: 100 }}
      />
      <div className="relative flex h-full min-h-[408px] flex-col overflow-hidden rounded-[27px] bg-[linear-gradient(180deg,rgba(18,18,20,.92),rgba(8,8,9,.96))] p-5 sm:p-6">
        <div className="pointer-events-none absolute -right-16 -top-16 size-48 rounded-full border border-white/[0.05]" />
        <div className="pointer-events-none absolute -right-8 -top-8 size-28 rounded-full border border-white/[0.04]" />

        <div className="flex items-start justify-between gap-4">
          <motion.div
            whileHover={{ rotate: [0, -7, 7, 0], scale: 1.05 }}
            transition={{ duration: 0.55 }}
            className="relative grid size-14 place-items-center overflow-hidden rounded-2xl border border-white/[0.10] bg-white/[0.05] shadow-[inset_0_1px_0_rgba(255,255,255,.08)]"
          >
            <div className={`absolute inset-0 bg-gradient-to-br ${product.accent}`} />
            <span className="relative text-base font-semibold text-white">{product.iconText}</span>
          </motion.div>
          {product.badge ? (
            <span className="rounded-full border border-white/10 bg-white/[0.045] px-3 py-1 text-[10px] font-medium tracking-[0.12em] text-white/55 uppercase">
              {product.badge}
            </span>
          ) : null}
        </div>

        <div className="mt-7">
          <p className="mb-2 text-[10px] font-medium tracking-[0.16em] text-white/35 uppercase">{product.category}</p>
          <h3 className="text-xl font-semibold tracking-[-0.025em] text-white">{product.name}</h3>
          <p className="mt-3 min-h-[56px] text-sm leading-6 text-white/45">{product.description}</p>
        </div>

        <div className="mt-5 space-y-2.5">
          {product.features.map((feature) => (
            <div key={feature} className="flex items-center gap-2.5 text-xs text-white/55">
              <span className="grid size-5 place-items-center rounded-full border border-emerald-300/10 bg-emerald-300/[0.05] text-emerald-200/70">
                <Check className="size-3" />
              </span>
              {feature}
            </div>
          ))}
        </div>

        <div className="mt-auto pt-7">
          <div className="mb-5 flex items-end justify-between gap-4 border-t border-white/[0.07] pt-5">
            <div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-semibold tracking-[-0.04em] text-white">{formatPrice(product.price)}</span>
                <span className="text-xs text-white/30">{product.period}</span>
              </div>
            </div>
            <div className="flex items-center gap-1.5 text-[10px] text-white/35">
              <Clock3 className="size-3" /> {product.delivery}
            </div>
          </div>

          <a
            href={telegramUrl}
            target="_blank"
            rel="noreferrer"
            data-cursor="Buy"
            className="relative flex h-11 w-full items-center justify-between overflow-hidden rounded-xl border border-white/10 bg-white/[0.055] px-4 text-sm font-medium text-white transition duration-300 hover:border-white/20 hover:bg-white/[0.09]"
          >
            <span className="absolute inset-y-0 -left-1/2 w-1/2 skew-x-[-18deg] bg-gradient-to-r from-transparent via-white/[0.12] to-transparent transition-transform duration-700 group-hover:translate-x-[430%]" />
            <span className="relative">Get {product.name}</span>
            <span className="relative grid size-7 place-items-center rounded-lg bg-white text-black transition-transform duration-300 group-hover:rotate-6 group-hover:scale-105">
              <ArrowUpRight className="size-3.5" />
            </span>
          </a>
        </div>
      </div>
    </motion.div>
  );
}
