"use client";

import { motion } from "framer-motion";
import { ArrowRight, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Magnetic } from "@/components/effects/magnetic";
import { siteConfig } from "@/lib/constants";

export function CTA() {
  return (
    <section className="px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 24, scale: 0.985 }}
        whileInView={{ opacity: 1, y: 0, scale: 1 }}
        viewport={{ once: true, amount: 0.25 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="relative mx-auto max-w-7xl overflow-hidden rounded-[36px] border border-white/[0.09] bg-[#0a0a0c] px-6 py-16 text-center shadow-[0_30px_120px_rgba(0,0,0,.5)] sm:px-10 sm:py-20 md:py-24"
      >
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_30%,rgba(124,92,255,.18),transparent_28%),radial-gradient(circle_at_75%_70%,rgba(61,238,255,.09),transparent_25%)]" />
        <div className="absolute left-1/2 top-0 h-px w-2/3 -translate-x-1/2 bg-gradient-to-r from-transparent via-white/40 to-transparent" />
        <div className="relative mx-auto max-w-3xl">
          <p className="text-[10px] font-medium tracking-[0.22em] text-cyan/60 uppercase">Ready when you are</p>
          <h2 className="mt-5 text-balance text-4xl font-semibold tracking-[-0.055em] text-white sm:text-5xl md:text-6xl lg:text-7xl">
            Your next premium app is a message away.
          </h2>
          <p className="mx-auto mt-6 max-w-xl text-sm leading-7 text-white/45 sm:text-base">
            Browse the collection or open Telegram and tell us exactly what you need. The rest of the flow stays simple.
          </p>
          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <Magnetic>
              <Button asChild size="lg">
                <a href="#apps" data-cursor="View">Browse apps <ArrowRight className="size-4" /></a>
              </Button>
            </Magnetic>
            <Magnetic>
              <Button asChild size="lg" variant="gradient">
                <a href={siteConfig.telegram} target="_blank" rel="noreferrer" data-cursor="Join"><Send className="size-4" /> Open Telegram</a>
              </Button>
            </Magnetic>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
