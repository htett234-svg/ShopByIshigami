"use client";

import * as React from "react";
import { AnimatePresence, motion } from "framer-motion";

export function PageLoader() {
  const [visible, setVisible] = React.useState(true);
  const [progress, setProgress] = React.useState(0);

  React.useEffect(() => {
    document.body.style.overflow = "hidden";
    let value = 0;
    const timer = window.setInterval(() => {
      value += Math.max(1, Math.round((100 - value) * 0.14));
      if (value >= 100) {
        value = 100;
        setProgress(value);
        window.clearInterval(timer);
        window.setTimeout(() => {
          setVisible(false);
          document.body.style.overflow = "";
        }, 280);
      } else {
        setProgress(value);
      }
    }, 55);

    return () => {
      window.clearInterval(timer);
      document.body.style.overflow = "";
    };
  }, []);

  return (
    <AnimatePresence>
      {visible ? (
        <motion.div
          className="fixed inset-0 z-[200] grid place-items-center overflow-hidden bg-[#050505]"
          exit={{ opacity: 0, scale: 1.02, filter: "blur(10px)" }}
          transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_45%,rgba(124,92,255,.16),transparent_28%)]" />
          <div className="relative w-[min(520px,82vw)] text-center">
            <motion.div
              initial={{ opacity: 0, y: 18, filter: "blur(10px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              transition={{ duration: 0.7 }}
              className="mb-10 text-[12px] font-medium tracking-[0.42em] text-white/85"
            >
              SHOP BY ISHIGAMI
            </motion.div>
            <div className="relative h-px overflow-hidden bg-white/10">
              <motion.div
                className="absolute inset-y-0 left-0 bg-gradient-to-r from-purple via-white to-cyan shadow-[0_0_30px_rgba(124,92,255,.8)]"
                animate={{ width: `${progress}%` }}
                transition={{ ease: "easeOut", duration: 0.16 }}
              />
            </div>
            <div className="mt-4 flex items-center justify-between text-[10px] tracking-[0.22em] text-white/30 uppercase">
              <span>Curating experience</span>
              <span>{progress.toString().padStart(3, "0")}%</span>
            </div>
          </div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}
