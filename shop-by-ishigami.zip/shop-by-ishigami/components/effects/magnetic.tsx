"use client";

import { useMagnetic } from "@/hooks/use-magnetic";
import { cn } from "@/lib/utils";

export function Magnetic({ children, className }: { children: React.ReactNode; className?: string }) {
  const ref = useMagnetic<HTMLDivElement>(0.16);
  return (
    <div ref={ref} className={cn("will-change-transform transition-transform duration-300 ease-out", className)}>
      {children}
    </div>
  );
}
