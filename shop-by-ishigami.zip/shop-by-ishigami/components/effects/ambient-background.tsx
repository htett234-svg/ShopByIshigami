"use client";

import * as React from "react";
import { motion, useMotionTemplate, useMotionValue, useSpring } from "framer-motion";

const particles = Array.from({ length: 28 }, (_, i) => ({
  id: i,
  left: `${(i * 37) % 100}%`,
  top: `${(i * 61) % 100}%`,
  delay: (i % 8) * 0.4,
  duration: 6 + (i % 6)
}));

export function AmbientBackground() {
  const x = useMotionValue(50);
  const y = useMotionValue(25);
  const smoothX = useSpring(x, { stiffness: 70, damping: 30 });
  const smoothY = useSpring(y, { stiffness: 70, damping: 30 });

  const background = useMotionTemplate`radial-gradient(circle at ${smoothX}% ${smoothY}%, rgba(124,92,255,.13), transparent 18%), radial-gradient(circle at 82% 12%, rgba(61,238,255,.08), transparent 22%), radial-gradient(circle at 20% 78%, rgba(124,92,255,.07), transparent 18%)`;

  React.useEffect(() => {
    const update = (e: MouseEvent) => {
      x.set((e.clientX / window.innerWidth) * 100);
      y.set((e.clientY / window.innerHeight) * 100);
    };
    window.addEventListener("mousemove", update, { passive: true });
    return () => window.removeEventListener("mousemove", update);
  }, [x, y]);

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-ink">
      <motion.div
        className="absolute -inset-[20%] opacity-80"
        style={{ background }}
      />
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,.017)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.017)_1px,transparent_1px)] bg-[size:64px_64px] [mask-image:linear-gradient(to_bottom,black,transparent_85%)]" />
      {particles.map((particle) => (
        <motion.span
          key={particle.id}
          className="absolute size-[2px] rounded-full bg-white/25 shadow-[0_0_8px_rgba(255,255,255,.35)]"
          style={{ left: particle.left, top: particle.top }}
          animate={{ y: [0, -14, 0], opacity: [0.12, 0.42, 0.12] }}
          transition={{ duration: particle.duration, delay: particle.delay, repeat: Infinity, ease: "easeInOut" }}
        />
      ))}
      <div className="noise absolute inset-0 opacity-[0.035]" />
      <div className="absolute inset-x-0 top-0 h-72 bg-gradient-to-b from-white/[0.025] to-transparent" />
    </div>
  );
}
