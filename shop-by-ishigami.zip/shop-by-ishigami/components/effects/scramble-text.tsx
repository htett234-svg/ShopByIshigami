"use client";

import * as React from "react";

const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789·✦";

export function ScrambleText({ text, className }: { text: string; className?: string }) {
  const [display, setDisplay] = React.useState(text);

  React.useEffect(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) return;

    let frame = 0;
    let iteration = 0;
    const total = text.length * 2;
    const update = () => {
      iteration += 0.45;
      setDisplay(
        text
          .split("")
          .map((char, index) => {
            if (char === " ") return " ";
            if (index < iteration / 2) return char;
            return chars[Math.floor(Math.random() * chars.length)];
          })
          .join("")
      );
      if (iteration < total) frame = requestAnimationFrame(update);
      else setDisplay(text);
    };
    frame = requestAnimationFrame(update);
    return () => cancelAnimationFrame(frame);
  }, [text]);

  return <span className={className} aria-label={text}>{display}</span>;
}
