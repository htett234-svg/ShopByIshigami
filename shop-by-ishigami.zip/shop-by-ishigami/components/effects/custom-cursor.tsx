"use client";

import * as React from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

export function CustomCursor() {
  const mouseX = useMotionValue(-100);
  const mouseY = useMotionValue(-100);
  const ringX = useSpring(mouseX, { stiffness: 420, damping: 38, mass: 0.35 });
  const ringY = useSpring(mouseY, { stiffness: 420, damping: 38, mass: 0.35 });
  const trailX = useSpring(mouseX, { stiffness: 150, damping: 28, mass: 0.45 });
  const trailY = useSpring(mouseY, { stiffness: 150, damping: 28, mass: 0.45 });
  const [label, setLabel] = React.useState("");
  const [active, setActive] = React.useState(false);
  const [enabled, setEnabled] = React.useState(false);

  React.useEffect(() => {
    const coarse = window.matchMedia("(pointer: coarse)").matches;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (coarse || reduced) return;
    setEnabled(true);

    const onMove = (e: MouseEvent) => {
      mouseX.set(e.clientX);
      mouseY.set(e.clientY);
    };
    const onOver = (e: MouseEvent) => {
      const target = (e.target as HTMLElement).closest<HTMLElement>("[data-cursor], a, button");
      if (!target) return;
      setActive(true);
      setLabel(target.dataset.cursor ?? "");
    };
    const onOut = (e: MouseEvent) => {
      const related = e.relatedTarget as Node | null;
      const target = (e.target as HTMLElement).closest<HTMLElement>("[data-cursor], a, button");
      if (target && (!related || !target.contains(related))) {
        setActive(false);
        setLabel("");
      }
    };

    window.addEventListener("mousemove", onMove, { passive: true });
    document.addEventListener("mouseover", onOver);
    document.addEventListener("mouseout", onOut);
    return () => {
      window.removeEventListener("mousemove", onMove);
      document.removeEventListener("mouseover", onOver);
      document.removeEventListener("mouseout", onOut);
    };
  }, [mouseX, mouseY]);

  if (!enabled) return null;

  return (
    <>
      <motion.div
        aria-hidden
        className="pointer-events-none fixed left-0 top-0 z-[248] size-4 rounded-full bg-purple/20 blur-[5px]"
        style={{ x: trailX, y: trailY }}
        transformTemplate={(_, generated) => `translate(-50%, -50%) ${generated}`}
      />
      <motion.div
        aria-hidden
        className="pointer-events-none fixed left-0 top-0 z-[250] size-2 rounded-full bg-white mix-blend-difference"
        style={{ x: mouseX, y: mouseY }}
        transformTemplate={(_, generated) => `translate(-50%, -50%) ${generated}`}
      />
      <motion.div
        aria-hidden
        className="pointer-events-none fixed left-0 top-0 z-[249] grid rounded-full border border-white/40 bg-white/[0.035] backdrop-blur-[2px]"
        style={{ x: ringX, y: ringY }}
        transformTemplate={(_, generated) => `translate(-50%, -50%) ${generated}`}
        animate={{
          width: active ? (label ? 74 : 44) : 28,
          height: active ? (label ? 74 : 44) : 28,
          boxShadow: active ? "0 0 40px rgba(124,92,255,.22)" : "0 0 0 rgba(0,0,0,0)"
        }}
        transition={{ type: "spring", stiffness: 330, damping: 25 }}
      >
        {label ? (
          <motion.span
            initial={{ opacity: 0, scale: 0.7 }}
            animate={{ opacity: 1, scale: 1 }}
            className="m-auto text-[9px] font-semibold tracking-[0.12em] text-white uppercase"
          >
            {label}
          </motion.span>
        ) : null}
      </motion.div>
    </>
  );
}
