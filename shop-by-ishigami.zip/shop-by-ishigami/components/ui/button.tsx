import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "group relative inline-flex items-center justify-center overflow-hidden rounded-full text-sm font-medium transition-all duration-300 after:pointer-events-none after:absolute after:left-1/2 after:top-1/2 after:size-0 after:-translate-x-1/2 after:-translate-y-1/2 after:rounded-full after:bg-white/25 after:opacity-0 after:transition-all after:duration-300 active:after:size-[180%] active:after:opacity-20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan/60 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default:
          "bg-white text-black shadow-[0_10px_50px_rgba(255,255,255,.08)] hover:-translate-y-0.5 hover:shadow-[0_18px_70px_rgba(255,255,255,.14)]",
        gradient:
          "border border-white/10 bg-[linear-gradient(110deg,rgba(124,92,255,.95),rgba(61,238,255,.78))] text-white shadow-[0_14px_60px_rgba(124,92,255,.25)] hover:-translate-y-0.5",
        outline:
          "border border-white/12 bg-white/[0.04] text-white backdrop-blur-xl hover:border-white/25 hover:bg-white/[0.07]",
        ghost: "text-white/75 hover:bg-white/[0.06] hover:text-white"
      },
      size: {
        default: "h-11 px-5",
        sm: "h-9 px-4 text-xs",
        lg: "h-12 px-6 text-[15px]",
        icon: "size-11"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, children, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props}>
        <span className="pointer-events-none absolute inset-0 -translate-x-[140%] bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-700 group-hover:translate-x-[140%]" />
        <span className="relative z-10 inline-flex items-center justify-center gap-2">{children}</span>
      </Comp>
    );
  }
);
Button.displayName = "Button";

export { Button, buttonVariants };
