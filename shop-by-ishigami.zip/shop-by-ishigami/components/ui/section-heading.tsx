import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  className
}: {
  eyebrow: string;
  title: React.ReactNode;
  description?: string;
  align?: "left" | "center";
  className?: string;
}) {
  return (
    <div className={cn("max-w-3xl", align === "center" && "mx-auto text-center", className)}>
      <Badge className="mb-5">{eyebrow}</Badge>
      <h2 className="text-balance text-3xl font-semibold tracking-[-0.045em] text-white sm:text-4xl md:text-5xl lg:text-[58px] lg:leading-[1.02]">
        {title}
      </h2>
      {description ? (
        <p className="mt-5 max-w-2xl text-sm leading-7 text-white/50 sm:text-base">{description}</p>
      ) : null}
    </div>
  );
}
