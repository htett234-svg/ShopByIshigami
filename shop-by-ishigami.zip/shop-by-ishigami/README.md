# SHOP BY ISHIGAMI

A premium dark-luxury digital subscription storefront built with Next.js 15, React 19, TypeScript, Tailwind CSS, Framer Motion, GSAP, Lenis, Three.js / React Three Fiber, Radix-based shadcn primitives, and Lucide icons.

## Highlights

- Immersive GSAP hero reveal with lazy-loaded React Three Fiber orb
- Lenis smooth scrolling with reduced-motion fallback
- Custom cursor with inner dot, elastic ring, glow trail and contextual labels
- Animated gradient/mesh background, particles, subtle stars, noise and mouse spotlight
- Page loader, scroll progress, floating dock and back-to-top interaction
- Interactive 3D-tilt product cards with glow tracking and shimmer
- Instant product search, category filtering and animated grid transitions
- Bento category section, number counters, feature cards and auto-scrolling testimonials
- Accessible Radix accordion FAQ and keyboard-visible focus states
- Responsive desktop/tablet/mobile navigation and layout
- App Router SEO metadata, dynamic Open Graph image, manifest, robots.txt and sitemap
- Privacy/Terms starter pages
- No remote product images required; product marks are safe typographic placeholders

## Run locally

```bash
cp .env.example .env.local
npm install
npm run dev
```

Open `http://localhost:3000`.

For a production check:

```bash
npm run typecheck
npm run build
npm start
```

## Launch configuration

Edit `.env.local`:

```env
NEXT_PUBLIC_SITE_URL=https://your-real-domain.com
NEXT_PUBLIC_TELEGRAM_URL=https://t.me/your-real-username
```

Then review `lib/constants.ts` to replace placeholder prices, delivery windows, feature copy and product availability with your real catalog.

The brief supplied `10,000+`, `99.9%`, testimonials and other commercial claims. They are included as design content; publish them only if you can substantiate them. The testimonial section itself also labels its entries as sample content.

## Brand assets

Product cards intentionally use typographic product marks rather than copied third-party logos. If you are authorized to use official product logos, place optimized SVG/WebP assets in `public/icons/` and render them with `next/image`.

## Legal / resale note

Before launch, confirm that your method of selling or activating each third-party subscription is allowed by the relevant provider and by applicable law. Replace the starter `/privacy` and `/terms` pages with policies tailored to your actual business, payment, refund, data handling and fulfillment practices.

## Performance strategy

The WebGL hero is dynamically imported and only rendered on the desktop hero layout. The rest of the site avoids image-heavy payloads, uses CSS for ambient visuals, respects `prefers-reduced-motion`, keeps animations transform/opacity-heavy, and leaves server-rendered sections server-side where interactivity is not required.

A Lighthouse score cannot be guaranteed independently of hosting, analytics, third-party scripts, network conditions and any assets you add. This project is structured to keep the baseline lean.

## Folder structure

```text
app/
  layout.tsx
  page.tsx
  globals.css
  manifest.ts
  robots.ts
  sitemap.ts
  opengraph-image.tsx
  not-found.tsx
  privacy/page.tsx
  terms/page.tsx
components/
  effects/
  layout/
  sections/
  three/
  ui/
hooks/
lib/
public/
  icons/
types/
```

## Customization map

- Products, reviews, FAQ, navigation: `lib/constants.ts`
- Global colors / spacing / animation tokens: `tailwind.config.ts`
- Global texture and browser behavior: `app/globals.css`
- Hero / headline: `components/sections/hero.tsx`
- WebGL art direction: `components/three/hero-orb.tsx`
- Product card visual language: `components/sections/product-card.tsx`
- SEO defaults: `app/layout.tsx`

## Deployment

The app is compatible with standard Next.js hosting. For Vercel, import the repository, set the two `NEXT_PUBLIC_*` environment variables, and deploy.
